//Addition of Two numbers

import java.util.Scanner;

public class AdditionOfNumbers {
	public static void main (String args[])
	{
		Scanner s=new Scanner (System.in);
		
		System.out.println("Enter ur name");
		String sname=s.nextLine();
		
		System.out.println("Enter num1 value");
		int num1 =s.nextInt();
		
		System.out.println("Enter num2 value");
		int num2 =s.nextInt();
		
		int result=num1+num2;
		
		System.out.println("Num1=" + num1);
		System.out.println("Num2=" + num2);
		System.out.println("Resulr=" + result);
	}
	

}
